from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField

class Article(models.Model):
    article_title = models.CharField('Name of statya', max_length=200)
    article_text = RichTextUploadingField()
    article_picture = models.TextField()
    article_small_text = models.TextField()
    pub_date = models.DateField('date of pub')


    def __str__(self):
        return self.article_title
