from django.shortcuts import render
from .models import Article
from django.http import Http404, HttpResponseRedirect
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.db.models import Q

def index(request):
    #поиск
    search_query = request.GET.get('search', '')
    if search_query:
        latest_articles_list = Article.objects.filter(Q(article_title__icontains=search_query) | Q(article_small_text__icontains=search_query))
    else:
        latest_articles_list = Article.objects.order_by('-pub_date')
    paginator = Paginator(latest_articles_list, 6)
    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)
    flag = paginator.num_pages - 1
    return render(request, 'article/article.html', {'posts':posts, 'flag':flag,})

def detail(request, article_id):
    try:
        a = Article.objects.get(id = article_id)
    except:
        raise Http404("Sorry")

    return render(request, 'article/articledetail.html',{'article':a})